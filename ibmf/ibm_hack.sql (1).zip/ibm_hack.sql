-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 28, 2019 at 06:25 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ibm_hack`
--

-- --------------------------------------------------------

--
-- Table structure for table `electric`
--

CREATE TABLE IF NOT EXISTS `electric` (
  `name` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `dateprob` date NOT NULL,
  `location` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `electric`
--

INSERT INTO `electric` (`name`, `mobile`, `dateprob`, `location`) VALUES
('soham dixit', '919199191919', '2019-04-30', 'guduvancheri');

-- --------------------------------------------------------

--
-- Table structure for table `excel_data`
--

CREATE TABLE IF NOT EXISTS `excel_data` (
  `Sl_No` int(11) DEFAULT NULL,
  `Landmark` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `Road` varchar(22) CHARACTER SET utf8 DEFAULT NULL,
  `Area` varchar(11) CHARACTER SET utf8 DEFAULT NULL,
  `TD` varchar(4) CHARACTER SET utf8 DEFAULT NULL,
  `Dam` int(11) DEFAULT NULL,
  `BlockCat` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `excel_data`
--

INSERT INTO `excel_data` (`Sl_No`, `Landmark`, `Road`, `Area`, `TD`, `Dam`, `BlockCat`) VALUES
(1, 'MGR Memorial', 'Kamrajar Salai', 'Chepauk', 'D01', 45, 3),
(2, 'TIDEL Park', 'Rajiv Gandhi Salai', 'Perumbakkam', 'D10', 67, 1),
(3, 'State Bank of India', 'JN Salai', 'Velachery', 'D44 ', 85, 3),
(4, 'Sunshine Secondary School', 'JN Salai', 'Velachery', 'D11', 34, 2),
(5, 'Axis Bank', 'Arcot Road', 'Tambaram', 'D01', 23, 1),
(6, 'Abdul Rahim Masjid ', 'Sardar Patel Road', 'Guindy', 'D40', 89, 3),
(7, 'Apple Store', 'JN Salai', 'T Nagar', 'D00', 65, 2),
(8, 'Kumaran Kundran Temple', 'Arcot Road', 'Tambaram', 'D40', 56, 1),
(9, 'Phoenix Market City', 'JN Salai', 'Velachery', 'D20', 50, 1),
(12, 'Axis Bank', 'Rajiv Gandhi Salai', 'Velachery', 'D11', 34, 2),
(13, 'Samsung Centre', 'Chennai-Trichy Highway', 'Tambaram', 'D01', 54, 1),
(15, 'AGS Cinemas', 'Rajiv Gandhi Salai', 'Perumbakkam', 'D40', 89, 3),
(16, 'Samsung Centre', 'JN Salai', 'T Nagar', 'D10', 45, 1),
(17, 'Guindy National Park', 'Chennai-Trichy Highway', 'Guindy', 'D20', 53, 2),
(19, 'Elliot''s Beach', 'Sardar Patel Road', 'Adyar', 'D01', 64, 1),
(20, 'Samsung Centre', 'JN Salai', 'T Nagar', 'D11', 34, 2),
(21, 'Infosys', 'Rajiv Gandhi Salai', 'Perumbakkam', 'D00', 76, 3),
(22, 'State Bank of India', 'JN Salai', 'T Nagar', 'D40', 76, 3),
(25, 'Marina Beach', 'Kamrajar Salai', 'Chepauk', 'D43', 62, 1),
(26, 'State Bank of India', 'Rajiv Gandhi Salai', 'Chepauk', 'D40', 98, 2),
(27, 'Iskon Temple', 'Rajiv Gandhi Salai', 'Perumbakkam', 'D43', 68, 1),
(28, 'State Bank of India', 'Chennai-Trichy Highway', 'Tambaram', 'D20', 78, 3),
(30, 'State Bank of India', 'Chennai-Trichy Highway', 'Tambaram', 'D20', 57, 2),
(31, 'Santhone Cathedral', 'Kamrajar Salai', 'Mylapore', 'D40', 87, 3),
(32, 'Yes Bank', 'Kamrajar Salai', 'Mylapore', 'D11', 76, 1),
(33, 'St. Thomas Mount Church', 'SH 48', 'Guindy', 'D40', 67, 2),
(36, 'Apple Store', 'Arcot Road', 'Chromepet', 'D43', 56, 2),
(37, 'Apple Store', 'Arcot Road', 'Vandalur', 'D11', 86, 3),
(38, 'Yes Bank', 'Rajiv Gandhi Salai', 'Guindy', 'D40', 56, 2),
(39, 'Vandalur Zoo', 'SH 48', 'Vandalur', 'D11', 59, 1),
(40, 'Samsung Centre', 'Anna Salai', 'Royapettah', 'D20', 99, 3),
(41, 'MGR Statue', 'Anna Salai', 'Royapettah', 'D00', 67, 1),
(45, 'Madhya Kailash Temple', 'Sardar Patel Road', 'Adyar', 'D00', 56, 3),
(47, 'Yes Bank', 'Chennai-Trichy Highway', 'Chromepet', 'D43', 90, 2),
(49, 'KCG College', 'Rajiv Gandhi Salai', 'Perumbakkam', 'D20', 86, 3);

-- --------------------------------------------------------

--
-- Table structure for table `person`
--

CREATE TABLE IF NOT EXISTS `person` (
  `name` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `person_name` varchar(255) NOT NULL,
  `person_mob` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `image` longblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `person`
--

INSERT INTO `person` (`name`, `mobile`, `person_name`, `person_mob`, `location`, `image`) VALUES
('shaurya sandoo', '9909304164', 'pratyaksh gupta', '9924812377', 'mm nagar', 0x5049434e44412e706e67),
('shaurya sandoo', '9909304164', 'hussain', '123456789', 'kodai', 0x5049434e4441202832292e706e67),
('shaurya', '9909304164', 'shaurya', '9924812356', 'tambaram', 0x70726f66696c652d696d6167652e706e67);

-- --------------------------------------------------------

--
-- Table structure for table `road`
--

CREATE TABLE IF NOT EXISTS `road` (
  `name` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `image` longblob NOT NULL,
  `action` int(10) unsigned zerofill NOT NULL DEFAULT '0000000000',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `road`
--

INSERT INTO `road` (`name`, `mobile`, `location`, `image`, `action`) VALUES
('abcdju124456', 'sdfgsrgg', 'potheri', 0x726f61642e706e67, 0000000000),
('Akash Mishra', '9564856657', 'Tambaram', 0x5049434e4441202832292e706e67, 0000000000),
('kaushik', '9909304164', 'guduvancheri', 0x726f61642d64616d6167652d6e65622e706e67, 0000000000),
('shaurya', '7878788885', 'Guduvancheri', 0x5049434e44412e706e67, 0000000000),
('shaurya1234', '9909304164', 'potheri', 0x5049434e4441202832292e706e67, 0000000000);

-- --------------------------------------------------------

--
-- Table structure for table `water`
--

CREATE TABLE IF NOT EXISTS `water` (
  `name` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `dateprob` date NOT NULL,
  `location` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `water`
--

INSERT INTO `water` (`name`, `mobile`, `dateprob`, `location`) VALUES
('shaurya sandoo', '8200505720', '2019-04-29', 'potheri'),
('atharv shah', '90992236548', '2019-05-01', 'pondy');
